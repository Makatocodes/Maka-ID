-- MakaID Database Schema
-- Run this on your MySQL server to create the backup database and user.

CREATE DATABASE IF NOT EXISTS `makaid_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `makaid_db`;

CREATE TABLE IF NOT EXISTS `backups` (
    `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
    `user_key` VARCHAR(128) NOT NULL,
    `data_json` LONGTEXT NOT NULL,
    `profile_name` VARCHAR(255) DEFAULT NULL,
    `profile_image` LONGTEXT DEFAULT NULL,
    `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (`id`),
    UNIQUE KEY `user_key_idx` (`user_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Optional database user for MakaID.
-- Replace the password with a strong value before use.
CREATE USER IF NOT EXISTS 'makaid_user'@'localhost' IDENTIFIED BY 'makaid_pass';
GRANT ALL PRIVILEGES ON `makaid_db`.* TO 'makaid_user'@'localhost';
FLUSH PRIVILEGES;
