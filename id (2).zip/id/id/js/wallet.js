const STORAGE_KEY = "ph_digital_wallet_data";

function getWalletData() {
    return JSON.parse(
        localStorage.getItem(STORAGE_KEY)
    ) || [];
}

function saveWalletData(data) {
    localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(data)
    );
}

function showAlert(icon, title, text) {
    if (typeof Swal === 'function') {
        Swal.fire({
            icon,
            title,
            text,
            confirmButtonColor: '#1e293b'
        });
    } else {
        alert(title + (text ? '\n' + text : ''));
    }
}

function getWalletBackupData() {
    return {
        walletData: getWalletData(),
        profileName: localStorage.getItem("walletProfileName") || null,
        profileImage: localStorage.getItem("walletProfileImage") || null,
        exportedAt: new Date().toISOString()
    };
}

function downloadBackupFile(filename, blob) {
    const downloadLink = document.createElement("a");
    downloadLink.href = URL.createObjectURL(blob);
    downloadLink.download = filename;
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
    URL.revokeObjectURL(downloadLink.href);
}

async function backupNow() {
    setBackupStatus("Preparing backup...");

    const backupData = getWalletBackupData();
    const timestamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, "_");
    const filename = `makaid_backup_${timestamp}.zip`;

    try {
        if (typeof JSZip !== "undefined") {
            const zip = new JSZip();
            zip.file("makaid_backup.json", JSON.stringify(backupData, null, 2));
            const blob = await zip.generateAsync({ type: "blob" });
            downloadBackupFile(filename, blob);
        } else {
            const blob = new Blob([JSON.stringify(backupData, null, 2)], { type: "application/json" });
            downloadBackupFile(`makaid_backup_${timestamp}.json`, blob);
        }

        setBackupStatus("Backup downloaded to your device.");
        showAlert("success", "Backup ready", "Your wallet backup ZIP is saved locally.");
    } catch (error) {
        console.error(error);
        setBackupStatus("Backup generation failed.", false);
        showAlert("error", "Backup failed", "Unable to create the backup file.");
    }
}

function setBackupStatus(message, success = true) {
    const status = document.getElementById("backupStatus");
    if (!status) return;
    status.textContent = message;
    status.classList.toggle("text-emerald-700", success);
    status.classList.toggle("text-rose-600", !success);
}


function getBase64(file) {
    return new Promise((resolve, reject) => {

        const reader = new FileReader();

        reader.onload = () =>
            resolve(reader.result);

        reader.onerror = reject;

        reader.readAsDataURL(file);

    });
}

async function generateAndSaveID() {

    const type =
        document.getElementById("id-type").value;

    const name =
        document.getElementById("id-name").value.trim();

    const number =
        document.getElementById("id-number").value.trim();

    const extra =
        document.getElementById("id-extra").value.trim();

    if (!name) {

        showAlert('warning', 'Missing name', 'Please enter full name.');
        return;
    }

    let photo = "";

    const photoInput =
        document.getElementById("id-photo");

    if (
        photoInput &&
        photoInput.files &&
        photoInput.files.length > 0
    ) {

        photo =
            await compressImage(
                photoInput.files[0]
            );
    }

    const walletData =
        getWalletData();

    walletData.unshift({

        id:
            "card_" + Date.now(),

        type:
            type,

        name:
            name,

        number:
            number,

        extra:
            extra,

        photo:
            photo,

        isManual:
            false,

        createdAt:
            Date.now()

    });

    saveWalletData(walletData);

    document.getElementById("id-name").value = "";
    document.getElementById("id-number").value = "";
    document.getElementById("id-extra").value = "";
    document.getElementById("id-photo").value = "";

    showSuccessModal(
        "Virtual ID saved successfully!"
    );
}

async function saveManualID(){

    if(!frontImage){

        showAlert(
            'warning',
            'Front image required',
            'Please upload front image.'
        );

        return;
    }

    try{

        const walletData =
        getWalletData();

        const newCard = {

            id:
            "manual_" +
            Date.now(),

            type:
            document
            .getElementById(
                "manual-type"
            )
            .value,

            front:
            frontImage,

            back:
            backImage || "",

            isManual:
            true,

            createdAt:
            Date.now()

        };

        walletData.unshift(
            newCard
        );

        saveWalletData(
            walletData
        );

        console.log(
            "Saved Manual ID",
            newCard
        );

        showSuccessModal(
            "Manual ID saved successfully!"
        );

    }catch(error){

        console.error(error);

        alert(
            "Failed to save ID. Images may be too large."
        );

    }

}

function previewFront(event) {

    const file =
        event.target.files[0];

    if (!file) return;

    const reader =
        new FileReader();

    reader.onload = function (e) {

        frontImage =
            e.target.result;

        const preview =
            document.getElementById(
                "frontPreview"
            );

        if (preview) {

            preview.src =
                frontImage;
        }
    };

    reader.readAsDataURL(file);
}

function previewBack(event) {

    const file =
        event.target.files[0];

    if (!file) return;

    const reader =
        new FileReader();

    reader.onload = function (e) {

        backImage =
            e.target.result;

        const preview =
            document.getElementById(
                "backPreview"
            );

        if (preview) {

            preview.src =
                backImage;
        }
    };

    reader.readAsDataURL(file);
}

function removeFront() {

    frontImage = "";

    document.getElementById(
        "frontPreview"
    ).src = "";

    document.getElementById(
        "frontInput"
    ).value = "";
}

function removeBack() {

    backImage = "";

    document.getElementById(
        "backPreview"
    ).src = "";

    document.getElementById(
        "backInput"
    ).value = "";
}

function flipCard() {

    const card =
        document.getElementById(
            "previewCard"
        );

    if (card) {

        card.classList.toggle(
            "flipped"
        );
    }
}

function flipWalletCard(id) {

    const card =
        document.getElementById(
            "card-" + id
        );

    if (card) {

        card.classList.toggle(
            "flipped"
        );
    }
}

function loadWalletCards() {

    const container =
        document.getElementById(
            "wallet-cards-container"
        );

    if (!container) return;

    const walletData =
        getWalletData();

    if (walletData.length === 0) {

        container.innerHTML = `
        <div class="bg-white p-6 rounded-2xl shadow text-center">
            <i class="fa-solid fa-wallet text-4xl text-slate-300 mb-3"></i>
            <h3 class="font-bold">
                No IDs Yet
            </h3>
        </div>
        `;

        return;
    }

    container.innerHTML = "";

    walletData.forEach(card => {

if(card.isManual){

container.innerHTML += `
<div class="bg-white rounded-2xl shadow overflow-hidden p-4">

<div class="flex justify-between items-center mb-3">

<h3 class="font-bold uppercase">
${card.type}
</h3>

<button
onclick="deleteCard('${card.id}')"
class="text-red-500">

<i class="fa-solid fa-trash"></i>

</button>

</div>

<div
class="wallet-flip-card"
onclick="this.classList.toggle('flipped')">

<div class="wallet-flip-inner">

<div class="wallet-front">

<img
src="${card.front}"
class="w-full rounded-xl border">

</div>

<div class="wallet-back">

<img
src="${card.back || card.front}"
class="w-full rounded-xl border">

</div>

</div>

</div>

<p class="text-xs text-center text-slate-500 mt-3">
Tap card to flip
</p>

</div>
`;
}else {

            container.innerHTML += `
            <div class="bg-white rounded-2xl shadow overflow-hidden mb-6">

                <div class="p-4 flex justify-between items-start">

                    <div class="flex gap-4">

                        <img
                        src="${
                            card.photo ||
                            'https://cdn-icons-png.flaticon.com/512/3135/3135715.png'
                        }"
                        class="w-20 h-20 rounded-xl object-cover border">

                        <div>

                            <h3 class="font-bold text-lg">
                                ${card.name || ""}
                            </h3>

                            <p class="text-sm text-slate-500">
                                ${card.number || ""}
                            </p>

                            <p class="text-sm text-slate-500">
                                ${card.extra || ""}
                            </p>

                            <span class="inline-block mt-2 text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">
                                ${card.type}
                            </span>

                        </div>

                    </div>

                    <button
                    onclick="deleteCard('${card.id}')"
                    class="text-red-500">

                        <i class="fa-solid fa-trash"></i>

                    </button>

                </div>

            </div>
            `;
        }

    });
}

function deleteCard(id) {

    if (!confirm(
        "Delete this ID?"
    )) return;

    let walletData =
        getWalletData();

    walletData =
        walletData.filter(
            card =>
            card.id !== id
        );

    saveWalletData(
        walletData
    );

    loadWalletCards();
}

function showSuccessModal(message) {

    const modal =
        document.getElementById(
            "successModal"
        );

    const msg =
        document.getElementById(
            "successMessage"
        );

    if (!modal) {

        location.href =
            "wallet-viewer.html";

        return;
    }

    if (msg) {

        msg.textContent =
            message;
    }

    modal.classList.remove(
        "hidden"
    );
}

function goToWallet() {

    window.location.href =
        "wallet-viewer.html";
}

async function compressImage(file) {

    return new Promise((resolve) => {

        const reader =
            new FileReader();

        reader.onload = function (e) {

            const img =
                new Image();

            img.onload =
                function () {

                const canvas =
                    document.createElement(
                        "canvas"
                    );

                const MAX_WIDTH =
                    500;

                const scale =
                    MAX_WIDTH /
                    img.width;

                canvas.width =
                    MAX_WIDTH;

                canvas.height =
                    img.height *
                    scale;

                const ctx =
                    canvas.getContext(
                        "2d"
                    );

                ctx.drawImage(
                    img,
                    0,
                    0,
                    canvas.width,
                    canvas.height
                );

                resolve(
                    canvas.toDataURL(
                        "image/jpeg",
                        0.6
                    )
                );
            };

            img.src =
                e.target.result;
        };

        reader.readAsDataURL(
            file
        );
    });
}

document.addEventListener(
    "DOMContentLoaded",
    function () {

        loadWalletCards();

    }
);