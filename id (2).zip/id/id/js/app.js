function switchScreen(screenId){
    document.querySelectorAll('.app-screen')
        .forEach(s=>s.classList.remove('active'));

    const screen =
        document.getElementById(`screen-${screenId}`);

    if(screen){
        screen.classList.add('active');
    }

    document.querySelectorAll('.nav-btn')
        .forEach(btn=>btn.classList.remove('active'));

    const activeBtn =
        document.querySelector(
            `[data-target="${screenId}"]`
        );

    if(activeBtn){
        activeBtn.classList.add('active');
    }

    if(screenId === 'wallet'){
        renderWallet();
    }
}

function logoutApp(){
    if (typeof Swal === 'function') {
        Swal.fire({
            icon: 'warning',
            title: 'Sign out?',
            text: 'Are you sure you want to logout?',
            showCancelButton: true,
            confirmButtonText: 'Logout',
            cancelButtonText: 'Cancel',
            confirmButtonColor: '#1e293b'
        }).then((result) => {
            if (result.isConfirmed) {
                location.reload();
            }
        });
    } else if (confirm("Are you sure you want to logout?")) {
        location.reload();
    }
}

function rateApp(){
    if (typeof Swal === 'function') {
        Swal.fire({
            title: 'Rate MakaID',
            input: 'range',
            inputAttributes: {
                min: 1,
                max: 5,
                step: 1
            },
            inputValue: 4,
            showCancelButton: true,
            confirmButtonText: 'Submit',
            cancelButtonText: 'Cancel',
            confirmButtonColor: '#1e293b'
        }).then((result) => {
            if (result.isConfirmed) {
                Swal.fire('Thank you!', `You rated MakaID ${result.value} ⭐`, 'success');
            }
        });
    } else {
        const rating = prompt("Rate MakaID (1-5 Stars):");
        if (rating) {
            alert(`Thank you for rating us ${rating} ⭐`);
        }
    }
}