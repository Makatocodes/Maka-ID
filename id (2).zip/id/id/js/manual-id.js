// ==========================
// MANUAL ID VARIABLES
// ==========================

let frontImage = "";
let backImage = "";
let cropper = null;
let cropTarget = null;

// ==========================
// IMAGE COMPRESSOR
// ==========================

async function compressManualImage(file){

    return new Promise((resolve)=>{

        const reader = new FileReader();

        reader.onload = function(e){

            const img = new Image();

            img.onload = function(){

                const canvas =
                document.createElement("canvas");

                const MAX_WIDTH = 800;

                const scale =
                MAX_WIDTH / img.width;

                canvas.width = MAX_WIDTH;

                canvas.height =
                img.height * scale;

                const ctx =
                canvas.getContext("2d");

                ctx.drawImage(
                    img,
                    0,
                    0,
                    canvas.width,
                    canvas.height
                );

                resolve(
                    canvas.toDataURL(
                        "image/jpeg",
                        0.7
                    )
                );

            };

            img.src = e.target.result;

        };

        reader.readAsDataURL(file);

    });

}

// ==========================
// SHOW VIRTUAL FORM
// ==========================

function showVirtualForm(){

    document
    .getElementById("selectOption")
    .classList.add("hidden");

    document
    .getElementById("virtualSection")
    .classList.remove("hidden");

}

// ==========================
// SHOW MANUAL FORM
// ==========================

function showManualForm(){

    document
    .getElementById("selectOption")
    .classList.add("hidden");

    document
    .getElementById("manualSection")
    .classList.remove("hidden");

}

// ==========================
// FRONT IMAGE
// ==========================

function previewFront(event){

    const file =
    event.target.files[0];

    if(!file) return;

    openCropper(file, "front");
}

// ==========================
// BACK IMAGE
// ==========================

function previewBack(event){

    const file =
    event.target.files[0];

    if(!file) return;

    openCropper(file, "back");
}

function openCropper(file, target){

    const reader = new FileReader();

    reader.onload = function(e){

        const image =
        document.getElementById(
            "cropImagePreview"
        );

        if(!image) return;

        cropTarget = target;

        destroyCropper();

        image.onload = function(){
            if(typeof Cropper === "function"){
                cropper = new Cropper(image, {
                    viewMode: 1,
                    autoCropArea: 0.8,
                    movable: true,
                    zoomable: true,
                    responsive: true,
                    background: true,
                    aspectRatio: NaN
                });
            }else{
                console.warn("Cropper.js not loaded, falling back to full image save.");
            }
        };

        image.src =
        e.target.result;

        document
        .getElementById(
            "cropModal"
        )
        .classList.add("active");
    };

    reader.readAsDataURL(file);
}

function destroyCropper(){
    if(cropper){
        cropper.destroy();
        cropper = null;
    }
}

function cancelCrop(){
    destroyCropper();

    if(cropTarget === "front"){
        document.getElementById("frontInput").value = "";
    } else if(cropTarget === "back"){
        document.getElementById("backInput").value = "";
    }

    cropTarget = null;

    document
    .getElementById(
        "cropModal"
    )
    .classList.remove("active");
}

function applyCrop(){

    if(!cropTarget) return;

    const image = document.getElementById("cropImagePreview");

    if(!image){
        alert("Crop image not available.");
        return;
    }

    let canvas;

    if(cropper){
        canvas = cropper.getCroppedCanvas({
            width: 1200,
            imageSmoothingQuality: "high"
        });
    } else {
        canvas = document.createElement("canvas");
        canvas.width = image.naturalWidth || 1200;
        canvas.height = image.naturalHeight || 1200;
        const ctx = canvas.getContext("2d");
        ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    }

    if(!canvas){
        alert("Could not crop the image.");
        return;
    }

    const croppedData =
    canvas.toDataURL("image/jpeg", 0.85);

    if(cropTarget === "front"){
        frontImage = croppedData;
        document
        .getElementById("frontPreview")
        .src = frontImage;
    } else if(cropTarget === "back"){
        backImage = croppedData;
        document
        .getElementById("backPreview")
        .src = backImage;
    }

    cropTarget = null;

    document
    .getElementById(
        "cropModal"
    )
    .classList.remove("active");

    destroyCropper();
}

// ==========================
// FLIP PREVIEW CARD
// ==========================

function flipCard(){

    document
    .getElementById("previewCard")
    .classList.toggle("flipped");

}

// ==========================
// REMOVE FRONT
// ==========================

function removeFront(){

    frontImage = "";

    document
    .getElementById("frontPreview")
    .src = "";

    document
    .getElementById("frontInput")
    .value = "";

}

// ==========================
// REMOVE BACK
// ==========================

function removeBack(){

    backImage = "";

    document
    .getElementById("backPreview")
    .src = "";

    document
    .getElementById("backInput")
    .value = "";

}

// ==========================
// SAVE MANUAL ID
// ==========================

function saveManualID(){

    if(!frontImage){

        alert(
            "Please upload front image."
        );

        return;
    }

    if(!backImage){

        alert(
            "Please upload back image."
        );

        return;
    }

    const walletData =
    getWalletData();

    const newID = {

        id:
        "manual_" +
        Date.now(),

        type:
        document
        .getElementById(
            "manual-type"
        )
        .value,

        front:
        frontImage,

        back:
        backImage,

        isManual:
        true,

        createdAt:
        Date.now()

    };

    walletData.unshift(
        newID
    );

    saveWalletData(
        walletData
    );

    if(
        typeof showSuccessModal ===
        "function"
    ){

        showSuccessModal(
            "ID saved successfully!"
        );

    }else{

        alert(
            "ID saved successfully!"
        );

        location.href =
        "wallet-viewer.html";

    }

}

document.addEventListener(
    "DOMContentLoaded",
    ()=>{
        console.log(
            "manual-id.js loaded"
        );
    }
);
async function compressImage(file){

    return new Promise((resolve)=>{

        const reader =
        new FileReader();

        reader.onload =
        function(e){

            const img =
            new Image();

            img.onload =
            function(){

                const canvas =
                document.createElement(
                    "canvas"
                );

                const ctx =
                canvas.getContext(
                    "2d"
                );

                const maxWidth =
                600;

                const scale =
                maxWidth /
                img.width;

                canvas.width =
                maxWidth;

                canvas.height =
                img.height *
                scale;

                ctx.drawImage(
                    img,
                    0,
                    0,
                    canvas.width,
                    canvas.height
                );

                resolve(
                    canvas.toDataURL(
                        "image/jpeg",
                        0.65
                    )
                );

            };

            img.src =
            e.target.result;

        };

        reader.readAsDataURL(
            file
        );

    });

}