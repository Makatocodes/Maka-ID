// ==========================
// MANUAL ID VARIABLES
// ==========================

let frontImage = "";
let backImage = "";

// ==========================
// IMAGE COMPRESSOR
// ==========================

async function compressManualImage(file){

    return new Promise((resolve)=>{

        const reader = new FileReader();

        reader.onload = function(e){

            const img = new Image();

            img.onload = function(){

                const canvas =
                document.createElement("canvas");

                const MAX_WIDTH = 800;

                const scale =
                MAX_WIDTH / img.width;

                canvas.width = MAX_WIDTH;

                canvas.height =
                img.height * scale;

                const ctx =
                canvas.getContext("2d");

                ctx.drawImage(
                    img,
                    0,
                    0,
                    canvas.width,
                    canvas.height
                );

                resolve(
                    canvas.toDataURL(
                        "image/jpeg",
                        0.7
                    )
                );

            };

            img.src = e.target.result;

        };

        reader.readAsDataURL(file);

    });

}

// ==========================
// SHOW VIRTUAL FORM
// ==========================

function showVirtualForm(){

    document
    .getElementById("selectOption")
    .classList.add("hidden");

    document
    .getElementById("virtualSection")
    .classList.remove("hidden");

}

// ==========================
// SHOW MANUAL FORM
// ==========================

function showManualForm(){

    document
    .getElementById("selectOption")
    .classList.add("hidden");

    document
    .getElementById("manualSection")
    .classList.remove("hidden");

}

// ==========================
// FRONT IMAGE
// ==========================

async function previewFront(event){

    const file =
    event.target.files[0];

    if(!file) return;

    frontImage =
    await compressImage(file);

    document
    .getElementById(
        "frontPreview"
    )
    .src =
    frontImage;

}

// ==========================
// BACK IMAGE
// ==========================

async function previewBack(event){

    const file =
    event.target.files[0];

    if(!file) return;

    backImage =
    await compressImage(file);

    document
    .getElementById(
        "backPreview"
    )
    .src =
    backImage;

}

// ==========================
// FLIP PREVIEW CARD
// ==========================

function flipCard(){

    document
    .getElementById("previewCard")
    .classList.toggle("flipped");

}

// ==========================
// REMOVE FRONT
// ==========================

function removeFront(){

    frontImage = "";

    document
    .getElementById("frontPreview")
    .src = "";

    document
    .getElementById("frontInput")
    .value = "";

}

// ==========================
// REMOVE BACK
// ==========================

function removeBack(){

    backImage = "";

    document
    .getElementById("backPreview")
    .src = "";

    document
    .getElementById("backInput")
    .value = "";

}

// ==========================
// SAVE MANUAL ID
// ==========================

function saveManualID(){

    if(!frontImage){

        alert(
            "Please upload front image."
        );

        return;
    }

    const walletData =
    getWalletData();

    const newID = {

        id:
        "manual_" +
        Date.now(),

        type:
        document
        .getElementById(
            "manual-type"
        )
        .value,

        front:
        frontImage,

        back:
        backImage,

        isManual:
        true,

        createdAt:
        Date.now()

    };

    walletData.unshift(
        newID
    );

    saveWalletData(
        walletData
    );

    if(
        typeof showSuccessModal ===
        "function"
    ){

        showSuccessModal(
            "ID saved successfully!"
        );

    }else{

        alert(
            "ID saved successfully!"
        );

        location.href =
        "wallet-viewer.html";

    }

}

document.addEventListener(
    "DOMContentLoaded",
    ()=>{
        console.log(
            "manual-id.js loaded"
        );
    }
);
async function compressImage(file){

    return new Promise((resolve)=>{

        const reader =
        new FileReader();

        reader.onload =
        function(e){

            const img =
            new Image();

            img.onload =
            function(){

                const canvas =
                document.createElement(
                    "canvas"
                );

                const ctx =
                canvas.getContext(
                    "2d"
                );

                const maxWidth =
                600;

                const scale =
                maxWidth /
                img.width;

                canvas.width =
                maxWidth;

                canvas.height =
                img.height *
                scale;

                ctx.drawImage(
                    img,
                    0,
                    0,
                    canvas.width,
                    canvas.height
                );

                resolve(
                    canvas.toDataURL(
                        "image/jpeg",
                        0.65
                    )
                );

            };

            img.src =
            e.target.result;

        };

        reader.readAsDataURL(
            file
        );

    });

}